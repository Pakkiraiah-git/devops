#! /bin/sh

echo shell scripting
